require 'gosu'

module ColorPalette
	# sky colors
	Top_sky_color = Gosu::Color.new 0xff025cb2 
  Bottom_sky_color = Gosu::Color.new 0xff52a5d9
end

class Filter
	def filter(array, size_x)
		
	end
end

require './height_map'
require './gaussian_filter'

height_map = HeightMap.new
height_map.number_of_drop_points = 60
height_map.min_particles = 400
height_map.max_particles = 800
height_map.number_of_passes = 4

height_map.generate(60, 60)

blur_filter = GaussianFilter.new
filtered_height_map = height_map.filter(blur_filter)
filtered_twice = height_map.filter(blur_filter).filter(blur_filter)

height_map.draw("rendered_maps/unfiltered.png")
filtered_height_map.draw("rendered_maps/filtered.png")
filtered_twice.draw("rendered_maps/filtered_twice.png")

require_relative './tile.rb'
require_relative './height_map'

# TODO: replace series of if elsif with more object oriented approach

class Map
	attr_accessor :width, :height
	attr_reader :tiles
	
	def initialize(width, height, height_map)
		@width = width
		@height = height
		
		@tiles = Array.new	
				
		(0...width).each do |x|
			(0...height).each do |y|
				if edge_of_map?(x, y)
					terrain = :water
				elsif height_map[x + y * width] == 0
					terrain = :water
				elsif height_map[x + y * width] >= 70
					terrain = :mountain
				elsif height_map[x + y * width] >= 1 && height_map[x + y * width] <= 2
					terrain = :sand
				elsif height_map[x + y * width] >= 30 && height_map[x + y * width] <= 50
					terrain = :forest
				else
					terrain = :grass
				end
				
				@tiles[x + y * width] = Tile.new(terrain, x, y)
			end
		end
	end		
	
	def tile_at(x, y)
		@tiles[x + y * @width]
	end

private

	def edge_of_map?(x, y)
		x == 0 || y == 0 || x == @width - 1 || y == @height - 1
	end	
end
